package jaron.sumo;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TaskStackBuilder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Calendar;

import static jaron.sumo.SumoActivity.CHANNEL_ID;



@SuppressLint("NewApi")
public class TimeAlarm extends BroadcastReceiver {
    String GROUP_KEY_SUMO = "com.android.sumo.notifications";
    private Context arg0;
    int nId = 0;


    @SuppressLint("NewApi")
    @Override
    // Main scheduled notification receiver
    public void onReceive(Context arg0, Intent arg1) {
        // TODO Auto-generated method stub
        this.arg0 = arg0;
        // Which meal: breakfast, lunch, dinner, snack, soul snack
        String meal = null;
        // Extra data
        String ex = null;
        ex = arg1.getStringExtra("extra");
        nId = ex.equals("a soul snack")
                ? arg1.getIntExtra("nId", 0)
                : 99; // Give meal reminders different channel
//        nId = arg1.getIntExtra("nId", 0);


        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (hour < 11) {
            meal = "breakfast";
        } else if (hour >= 11 && hour <= 17) {
            meal = "lunch";
        } else if (hour > 17) {
            meal = "dinner";
        }


        // Primary notification
        final Notification.Builder mBuilder = new Notification.Builder(arg0, CHANNEL_ID)// Channel id arbi
            .setSmallIcon(R.drawable.d3_icon)
            .setContentTitle("Time to eat " + (ex != null ? ex : meal))
            .setShowWhen(true)
            .setSound(null);
        final Notification.InboxStyle inboxStyle = new Notification.InboxStyle();
        Log.d("DEBUG", "on recccc");

        // Put extra messagae in obj
        final Intent resultIntent = new Intent(arg0, SumoActivity.class);

        boolean doMore = false;
        try {
            HandleXML obj;
            ConnectivityManager cm =
                (ConnectivityManager) arg0.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
            boolean isConnected = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

            if (!isConnected) {
                Log.d("DEBUG", "IS NOT CONNECTED");
            }
        } catch (Exception e) {
            Toast.makeText(arg0, "Trouble doing noti", Toast.LENGTH_SHORT).show();
        }

        mBuilder.setLights(Color.BLUE, 500, 500);
        // Don't think this does anything?:
        mBuilder.setTicker("It is time to eadddddddt " + (ex != null ? ex : meal) + "!");
        mBuilder.setAutoCancel(false);


        Intent intentEven = new Intent(arg0, SumoActivity.class);
        Intent intentOdd = new Intent(arg0, SumoActivity.class);
        Intent intentMore = new Intent(arg0, SumoActivity.class);
        Intent intentEat = new Intent(arg0, SumoActivity.class);
        Intent intentSaveFave = new Intent(arg0, SumoActivity.class);

        intentEven.putExtra("ieven", true);
        intentOdd.putExtra("iodd", true);
        intentMore.putExtra("imore", true);
        intentEat.putExtra("eat", true);
        intentSaveFave.putExtra("saveFavorite", true);

        PendingIntent evpi = PendingIntent.getActivity(arg0, 9, intentEven, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent oddpi = PendingIntent.getActivity(arg0, 8, intentOdd, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent morepi = PendingIntent.getActivity(arg0, 10, intentMore, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent eatpi = PendingIntent.getActivity(arg0, 11, intentEat, PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent saveFavePi = PendingIntent.getActivity(arg0, 12, intentSaveFave, PendingIntent.FLAG_UPDATE_CURRENT);


        Log.d("STATE", "Variable EX =  " + ex);


        // Moves the day's info into the notification object.
        mBuilder
            // Buttons: Even or odd
            .addAction(R.drawable.d1_icon,
                ("Odd"), oddpi)
            .addAction(R.drawable.d2_icon,
                ("Even"), evpi);

        // Deprecate jaron 4/9/2021
//        if (doMore && (
//                ex.equals("a snack")
//                || ex.equals("some breakfast")
//                || ex.equals("some lunch")
//                || ex.equals("some dinner")))
//        {
//            mBuilder.addAction(R.drawable.d3_icon,
//                    ("More"), morepi);
//        }


        // Replace eat with favorite for soul snack:
        if (!ex.equals("a soul snack")) {
            mBuilder.addAction(R.drawable.d3_icon,
                ("Eat"), eatpi);
        }


        // mId allows you to update the notification later on.

        Log.d("STATE", " EXECUTE ONCE!!!!!!!!!!!!!!!");

        // boolean isUiThread = Looper.getMainLooper().isCurrentThread();
        TaskStackBuilder stackBuilder = TaskStackBuilder.create(arg0);
        // Adds the back stack for the Intent (but not the Intent itself)
        stackBuilder.addParentStack(SumoActivity.class);
        // Adds the Intent that starts the Activity to the top of the stack

        new Noti(inboxStyle, mBuilder, resultIntent, nId, ex, stackBuilder, intentSaveFave, saveFavePi).execute("ASDF");
    }

    private class Noti extends AsyncTask<String, Void, String> {
        Notification.InboxStyle inboxStyle;
        Notification.Builder mBuilder;
        Intent resultIntent;
        Intent saveFaveIntent;
        PendingIntent saveFavePi;
        Integer nId;
        NotificationManager mNotificationManager;
        String ex;
        TaskStackBuilder stackBuilder;

        Noti(Notification.InboxStyle ib, Notification.Builder mb, Intent ri, Integer nodeId, String snackType, TaskStackBuilder stackBuilder, Intent saveFaveIntent, PendingIntent saveFavePi) {
            // list all the parameters like in normal class define
            this.inboxStyle = ib;
            this.mBuilder = mb;
            this.resultIntent = ri;
            this.saveFaveIntent = saveFaveIntent;
            this.saveFavePi = saveFavePi;
            this.nId = nodeId;
            this.ex = snackType;
            this.stackBuilder = stackBuilder;
        }

        // Primary async data grabber
        protected String doInBackground(String... strs) {
            Log.d("STATE", " HOW IF EVER???????????HOW IF EVER???????????HOW IF EVER???????????HOW IF EVER???????????");
            String message = "";
            this.mBuilder.setGroup(GROUP_KEY_SUMO);

            if (ex.equals("a soul snack")) {
                // This is actual:
                HandleXML obj = new HandleXML("https://beta.ourmanna.com/api/v1/get/?format=text&order=random");

                obj.fetchXML(this.inboxStyle, this.mBuilder);
                this.resultIntent.putExtra("showMessage", true);
                this.resultIntent.putExtra("isVerse", true);
                this.resultIntent.putExtra("message", obj.message);
                if (obj.message.equals("")) {
                    this.cancel(true);
                    Log.d("STATE", "Cancel notification, no content received");
                }
                message = obj.message;
            } else {
                boolean doMore = false;
                // This is actual - jaron 3/28/21:
                HandleXML obj = new HandleXML("https://www.checkiday.com/rss.php?tz=America/Los_Angeles");
                obj.fetchXML(inboxStyle, mBuilder);

                if (obj.allHolidays.equals("")) {
                    this.cancel(true);
                    Log.d("STATE", "Cancel notification, no content received");
                }

                resultIntent.putExtra("showMessage", true);
                resultIntent.putExtra("message", obj.allHolidays);

                // This displays truncated when notification is collapsed:
                // this.mBuilder.setContentText(obj.allHolidays);

                this.mBuilder.setStyle(new Notification.BigTextStyle()
                    .bigText(obj.allHolidays)
                    .setSummaryText(obj.allCounter + " holidays: " + obj.allHolidays)
                );
                message = obj.allHolidays;
            }
            this.saveFaveIntent.putExtra("message", message);


            return "meaningless";
        }

        protected void onProgressUpdate() {
            //finalResult.setText(text[0]);
        }

        // Main notifier after retrieving information from internet
        protected void onPostExecute(String str) {




            Log.d("STATE", " HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHOW IF EVER???????????");

            if (this.ex.equals("a soul snack")) {
                //Do only for soul snack
                PendingIntent saveFavePi = PendingIntent.getActivity(arg0, 12, this.saveFaveIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                mBuilder.addAction(R.drawable.d3_icon,
                    ("Favorite"), saveFavePi);
            }

            // The stack builder object will contain an artificial back stack for the
            // started Activity.
            // This ensures that navigating backward from the Activity leads out of
            // your application to the Home screen.
            stackBuilder.addNextIntent(this.resultIntent);

            PendingIntent resultPendingIntent = PendingIntent.getActivity(
                arg0,
                (this.ex.equals("a soul snack") ? 222 : 223),
                this.resultIntent,
                PendingIntent.FLAG_UPDATE_CURRENT);
            this.mBuilder.setContentIntent(resultPendingIntent);
            NotificationManager mNotificationManager =
                (NotificationManager) arg0.getSystemService(Context.NOTIFICATION_SERVICE);



            mNotificationManager.notify(this.nId, this.mBuilder.build());
        }
    }

    private static String convertStreamToString(InputStream is) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();

        String line = null;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }
}
