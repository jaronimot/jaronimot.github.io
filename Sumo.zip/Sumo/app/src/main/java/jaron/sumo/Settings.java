package jaron.sumo;

import android.app.ActionBar;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.view.MenuItem;

public class Settings extends PreferenceActivity  {

    private static final String KEY_REMINDER = "reminders";
    private static final String KEY_SNACK = "snack";
    private static final String KEY_SOUL = "soul";
    private static final String KEY_MEAL = "meal";

	@Override
    public void onCreate(Bundle savedInstanceState)
    {
            super.onCreate(savedInstanceState);

    	    ActionBar actionBar = getActionBar();
    	    actionBar.setDisplayHomeAsUpEnabled(true);

             // add the xml resource                     
            addPreferencesFromResource(R.xml.settings);
    }
	
	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
        case android.R.id.home:
            // app icon in action bar clicked; goto parent activity.
            onBackPressed();
            return true;
		}
		return false;
	}

}

