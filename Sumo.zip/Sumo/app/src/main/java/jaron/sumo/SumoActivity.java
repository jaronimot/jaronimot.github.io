package jaron.sumo;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.FragmentTransaction;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.PendingIntent.CanceledException;
import android.app.backup.BackupAgentHelper;
import android.app.backup.BackupManager;
import android.app.backup.FileBackupHelper;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.graphics.drawable.AnimationDrawable;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.NotificationCompat;
import android.support.v4.view.ViewPager;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Scroller;
import android.widget.SlidingDrawer;
import android.widget.SlidingDrawer.OnDrawerCloseListener;
import android.widget.TabHost;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;


@SuppressLint("NewApi")
public class SumoActivity extends FragmentActivity implements ActionBar.TabListener {

    public static final String CHANNEL_ID = "SumoChannelId";
    static final String FILES_BACKUP_KEY = "myfiles";
    private static final String BALANCE_FILENAME = "balance.txt";
    private static final String HIGHSCORE_FILENAME = "highscore.txt";
    private static final String HIGHSTREAK_FILENAME = "highscore.streak.txt";
    private static final String CURSTREAK_FILENAME = "current.streak.txt";
    private static final String FAVORITE_VERSES_FILENAME = "verses.favorite.json";
    private static final WebChromeClient WebChromeClient = null;
    public static WebView ewb;
    static AnimationDrawable sumoAnim;
    static ImageView sumoImage;
    static ImageView d1;
    static ImageView d2;
    static EditText b;
    static TextSwitcher ts;
    static String theNewB;
    static View rootView;
    private static OnSharedPreferenceChangeListener mPreferenceListener = null;
    Random randomGenerator;
    int randomInt1;
    int randomInt2;
    int dieSum;
    WebView mWebView;
    WebView mWebView2;
    WebView mWebView3;
    // Swipe tab
    WebView mWebView4;
    SlidingDrawer sd;
    /**
     * The {@link android.support.v4.view.PagerAdapter} that will provide fragments representing
     * each object in a collection. We use a {@link android.support.v4.app.FragmentStatePagerAdapter}
     * derivative, which will destroy and re-create fragments as needed, saving and restoring their
     * state in the process. This is important to conserve memory and is a best practice when
     * allowing navigation between objects in a potentially large collection.
     */
    AppSectionsPagerAdapter mAppSectionsPagerAdapter;
    /**
     * The {@link ViewPager} that will display the three primary sections of the app, one at a
     * time.
     */
    ViewPager mViewPager;
    private TabHost mTabHost;

    /**
     * Called when the activity is first created.
     */
    @SuppressLint("NewApi")
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        this.createNotificationChannel();



        // Create the adapter that will return a fragment for each of the three primary sections
        // of the app.
        mAppSectionsPagerAdapter = new AppSectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager, attaching the adapter and setting up a listener for when the
        // user swipes between sections.
        mViewPager = (ViewPager) findViewById(R.id.pager);
        mViewPager.setAdapter(mAppSectionsPagerAdapter);
        mViewPager.setOffscreenPageLimit(4);


        class TheBackupAgent extends BackupAgentHelper {
            // Allocate a helper and add it to the backup agent
            @Override
            public void onCreate() {
                FileBackupHelper helper = new FileBackupHelper(this, BALANCE_FILENAME, HIGHSCORE_FILENAME, HIGHSTREAK_FILENAME, CURSTREAK_FILENAME, FAVORITE_VERSES_FILENAME);
                addHelper(FILES_BACKUP_KEY, helper);
            }
        }

        BackupManager bm = new BackupManager(this);
        bm.dataChanged();


        sd = (SlidingDrawer) findViewById(R.id.slidingDrawer1);
        sd.setOnDrawerCloseListener(new OnDrawerCloseListener() {
            public void onDrawerClosed() {
                mWebView.clearCache(true);
                mWebView.loadUrl("https://www.factretriever.com/");
            }
        });


        theNewB = "";
        try {
            theNewB = readFile(BALANCE_FILENAME);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        if (theNewB == "") {
            fileCreate(BALANCE_FILENAME, "150");
        }

        int curBalance = Math.abs(Integer.parseInt(theNewB));

        String highscore = null;
        try {
            highscore = readFile(HIGHSCORE_FILENAME);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            // Initialize high score data item
            highscore = (curBalance > 150 ? theNewB : "150");
            fileCreate(HIGHSCORE_FILENAME, highscore);
            e.printStackTrace();
        }

        initWebViews();

        SharedPreferences sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this);
        // reminders == meal (main)
        if (sharedPrefs.getBoolean("reminders", true)) {
            this.remindersToggle(true);
        }
        // snackReminders
        if (sharedPrefs.getBoolean("snackReminders", true)) {
            this.snackRemindersToggle(true);
        }
        // soulSnackReminders
        if (sharedPrefs.getBoolean("soulSnackReminders", true)) {
            this.soulSnackRemindersToggle(true);
        }
        mPreferenceListener = new PreferenceChangeListener();
        sharedPrefs.registerOnSharedPreferenceChangeListener(mPreferenceListener);

        if (getIntent().getBooleanExtra("imore", false)) {
            HandleXML obj = new HandleXML("https://www.checkiday.com/rss.php");
            obj.getHolidayString();

            //Toast.makeText(this, "show all hollys", Toast.LENGTH_LONG).show();
            AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("All Holidays")
                .setMessage(obj.allHolidays)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .setIcon(R.drawable.d3_icon)
                .show();
            TextView textView = (TextView) dialog.findViewById(android.R.id.message);
            textView.setScroller(new Scroller(this));
            textView.setVerticalScrollBarEnabled(true);
            textView.setMovementMethod(new ScrollingMovementMethod());

        }

        if (getIntent().getBooleanExtra("eat", false)) {
            // Get randmon food option:
            this.alertRandomFood();
        }

        if (getIntent().getBooleanExtra("showMessage", false)) {
            if (getIntent().getStringExtra("message") != null) {
                this.alertMessage(getIntent().getStringExtra("message"), getIntent().getBooleanExtra("isVerse", false));
            }
        }

        if (getIntent().getBooleanExtra("saveFavorite", false)) {
            Log.d("STATE", "Save Fave");
            this.saveFavorite(getIntent().getStringExtra("message"));
        }
    }// end main onCreate


    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_LOW;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            channel.setSound(null, null);
            // Register the channel with the system; you can't change the importance
            // or other notification behaviors after this
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


    private void initWebViews() {
        // TODO Auto-generated method stub
        mWebView = (WebView) findViewById(R.id.webview);
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setSupportMultipleWindows(true);
        mWebView.getSettings().setAllowFileAccess(true);
        mWebView.getSettings().setBuiltInZoomControls(true);
        mWebView.getSettings().setLoadWithOverviewMode(true);
        mWebView.getSettings().setUseWideViewPort(true);
        mWebView.setWebViewClient(new HelloWebViewClient());
        mWebView.setWebChromeClient(new WebChromeClient());
        mWebView.loadUrl("https://www.factretriever.com/");
    }

    // Instructions given by intent to do various in app functions
    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);


        // Handle even/odd choice from notification button
        //Toast.makeText(getBaseContext(), "new intent!", Toast.LENGTH_SHORT).show();
        if (intent == null) {
            //Toast.makeText(getBaseContext(), "null inent!", Toast.LENGTH_SHORT).show();
        } else {
            if (intent.getBooleanExtra("iodd", false)) {
                eooClick(findViewById(R.id.bOdd));
            }

            if (intent.getBooleanExtra("ieven", false)) {
                eooClick(findViewById(R.id.bEven));
            }

            if (intent.getBooleanExtra("imore", false)) {
                // Open todays' holidy tab
                HandleXML obj = new HandleXML("https://www.checkiday.com/rss.php");
                obj.getHolidayString();

                //Toast.makeText(getBaseContext(), "show all hollys33", Toast.LENGTH_LONG).show();
                AlertDialog dialog = new AlertDialog.Builder(this)
                    .setTitle("All Holidaysz")
                    .setMessage(obj.allHolidays)
                    .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .setIcon(R.drawable.d3_icon)
                    .show();
                TextView textView = (TextView) dialog.findViewById(android.R.id.message);
                textView.setScroller(new Scroller(this));
                textView.setVerticalScrollBarEnabled(true);
                textView.setMovementMethod(new ScrollingMovementMethod());
            }

            if (intent.getBooleanExtra("saveFavorite", false)) {
                Log.d("STATE", "Save Fave");
                this.saveFavorite(getIntent().getStringExtra("message"));
            }

            if (intent.getBooleanExtra("eat", false)) {
                // Get randmon food option:
                this.alertRandomFood();
            }

            if (intent.getBooleanExtra("showMessage", false)) {
                this.alertMessage(getIntent().getStringExtra("message"), getIntent().getBooleanExtra("isVerse", false));
            }
        }
    }

    public String getRandomFood() {
        List<String> list = new ArrayList<String>();
        list.add("Teriyaki");
        list.add("Ezell's");
        list.add("Sushi");
        list.add("Ramen");
        list.add("Sandwiches");
        list.add("Pizza");
        list.add("Burgers");
        list.add("Steak and rice");
        list.add("Chicken and rice");
        list.add("Eggs");
        list.add("Tacos!");
        list.add("Chinese");
        list.add("Italian");
        list.add("Padria");
        list.add("Hot dogs");
        list.add("Stir Fry");
        list.add("Shake and Go");
        list.add("Chick Fil A");
        list.add("Thai");
        list.add("Mi Tierra");
        list.add("Indian food");
        list.add("New Food");
        list.add("Fish n Chips");
        list.add("Gyro");
        list.add("Nick's grill");
        list.add("Chinese");
        list.add("La Corona");
        list.add("Grilled Cheese");

        return list.get(new Random().nextInt(list.size()));
    }

    public void alertRandomFood() {
        // Alert food option
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Eat Some Food!")
            .setMessage("Eat " + this.getRandomFood())
            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            })
            .setIcon(R.drawable.d3_icon)
            .show();
        TextView textView = (TextView) dialog.findViewById(android.R.id.message);
        //textView.setMaxLines(5);
        textView.setScroller(new Scroller(this));
        textView.setVerticalScrollBarEnabled(true);
        textView.setMovementMethod(new ScrollingMovementMethod());
    }

    public String createJsonString(String favorites, String add) throws JSONException {
        JSONArray verses = new JSONArray(favorites);

        // Remove older if in already
        for (int i = 0; i < verses.length(); i++) {
            if (verses.getString(i).equals(add)) {
                verses.remove(i);
            }
        }

        // Add it to end
        if (!add.equals("") && !favorites.contains(add)) {
            verses.put(add);
        }

        try {
            return verses.toString(2);
        } catch (JSONException e) {
            e.printStackTrace();
            return "";
        }
    }

    public String listJsonArray(String favorites) throws JSONException {
        JSONArray verses = new JSONArray(favorites);
        StringBuilder favoriteList = new StringBuilder("");
        for (int i = verses.length() - 1; i >= 0; i--) {
            favoriteList.append("*** " + verses.getString(i) + (i > 0 ? "\n\n" : ""));
        }
        String faves = favoriteList.toString();
        return faves.equals("") ? "No Favorites" : faves;
    }

    public void saveFavorite(String mes) {
        String favorites = null;
        try {
            favorites = readFile(FAVORITE_VERSES_FILENAME);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            favorites = "[]";
            e.printStackTrace();
        }

        String json = null;
        try {
            json = createJsonString(favorites, mes);
        } catch (JSONException e) {
            json = "[]";
            e.printStackTrace();
        }
        favorites += mes;


        Toast.makeText(getBaseContext(), "Adding " + mes, Toast.LENGTH_LONG).show();

        fileCreate(FAVORITE_VERSES_FILENAME, json);
    }

    public void clearFavorites()
    {
        fileCreate(FAVORITE_VERSES_FILENAME, "[]");
    }

    public void alertMessage(final String mes, boolean isVerse) {
        // Alert food option
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
            .setTitle(isVerse ? "Message!" : "Holidays!")
            .setMessage(mes)
            .setIcon(R.drawable.d3_icon)
            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
        if (isVerse) {
            dialog.setNeutralButton("Favorite", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    saveFavorite(mes);
                    dialog.dismiss();
                }
            });
        }
        dialog.show();
		/*
		TextView textView = (TextView) dialog.findViewById(android.R.id.message);
		//textView.setMaxLines(5);
		textView.setScroller(new Scroller(this));
		textView.setVerticalScrollBarEnabled(true);
		textView.setMovementMethod(new ScrollingMovementMethod());
		*/
    }

    public void remindersToggle(boolean toggle) {
        // Retrieve alarm manager from the system
        // Every scheduled intent needs a different ID, else it is just executed once
        // Prepare the intent which should be launched at the date
        // Set pending intent to go on the next minute recurring 15
        // Get new calendar object and set the date to now

        AlarmManager alarmManager = (AlarmManager) getApplicationContext().getSystemService(getBaseContext().ALARM_SERVICE);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        int minute = Calendar.getInstance().get(Calendar.MINUTE);

        int mealReminderId = 99;


        // Register meals
        Intent intentB = new Intent(this, TimeAlarm.class);
        Intent intentL = new Intent(this, TimeAlarm.class);
        Intent intentD = new Intent(this, TimeAlarm.class);
        // Register verse
        Intent intentV = new Intent(this, TimeAlarm.class);


        //Toast.makeText(getBaseContext(), "Creating meals!", Toast.LENGTH_LONG).show();
        calendar.setTimeInMillis(System.currentTimeMillis());
        if (hour >= 7) {
            // Add a day
            calendar.add(Calendar.HOUR, 24);
        }
        intentB.putExtra("extra", "some breakfast");
        intentB.putExtra("nId", mealReminderId);
        PendingIntent bIntent = PendingIntent.getBroadcast(getApplicationContext(), 2, intentB, PendingIntent.FLAG_UPDATE_CURRENT);
        calendar.set(Calendar.HOUR_OF_DAY, 5);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        if (toggle) {
            alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY, bIntent);
        } else {
            alarmManager.cancel(bIntent);
        }


        // Lunch reminder
        calendar.setTimeInMillis(System.currentTimeMillis());
        if (hour >= 11) {
            // Add a day
            calendar.add(Calendar.HOUR, 24);
        }
        intentL.putExtra("extra", "some lunch");
        intentL.putExtra("nId", mealReminderId);
        PendingIntent lIntent = PendingIntent.getBroadcast(getApplicationContext(), 3, intentL, PendingIntent.FLAG_UPDATE_CURRENT);
        calendar.set(Calendar.HOUR_OF_DAY, 11);
        calendar.set(Calendar.MINUTE, 30);
        calendar.set(Calendar.SECOND, 0);
        if (toggle) {
            alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY, lIntent);
        } else {
            alarmManager.cancel(lIntent);
        }


        // Dinner reminder
        calendar.setTimeInMillis(System.currentTimeMillis());
        if (hour >= 17) {
            // Add a day, so as to not get immediately notified
            calendar.add(Calendar.HOUR, 24);
        }
        intentD.putExtra("extra", "some dinner");
        intentD.putExtra("nId", mealReminderId);
        PendingIntent dIntent = PendingIntent.getBroadcast(getApplicationContext(), 4, intentD, PendingIntent.FLAG_UPDATE_CURRENT);
        // hour: 17, 5pm dinner
        calendar.set(Calendar.HOUR_OF_DAY, 17);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        if (toggle) {
            alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY, dIntent);
        } else {
            alarmManager.cancel(dIntent);
        }
    }

    public void snackRemindersToggle(boolean toggle) {
        // Retrieve alarm manager from the system
        // Every scheduled intent needs a different ID, else it is just executed once
        // Prepare the intent which should be launched at the date
        // Set pending intent to go on the next minute recurring 15
        // Get new calendar object and set the date to now

        AlarmManager alarmManager = (AlarmManager) getApplicationContext().getSystemService(getBaseContext().ALARM_SERVICE);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        //int minute = Calendar.getInstance().get(Calendar.MINUTE);

        Intent intent = new Intent(this, TimeAlarm.class);

        intent.putExtra("extra", "a snack");
        intent.putExtra("nId", 5);
        calendar.set(Calendar.HOUR_OF_DAY, 5);
        calendar.set(Calendar.MINUTE, 30);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, PendingIntent.FLAG_UPDATE_CURRENT);
        if (toggle) {
            alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_HALF_DAY, pendingIntent);
            if (false)// debug
            {
                try {
                    pendingIntent.send();
                } catch (CanceledException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        } else {
            alarmManager.cancel(pendingIntent);
        }
    }

    public void soulSnackRemindersToggle(boolean toggle) {
        // Retrieve alarm manager from the system
        // Every scheduled intent needs a different ID, else it is just executed once
        // Prepare the intent which should be launched at the date
        // Set pending intent to go on the next minute recurring 15
        // Get new calendar object and set the date to now
        AlarmManager alarmManager = (AlarmManager) getApplicationContext().getSystemService(getBaseContext().ALARM_SERVICE);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        int hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        //int minute = Calendar.getInstance().get(Calendar.MINUTE);

        Intent intentV = new Intent(this, TimeAlarm.class);

        // Verse reminder
        //calendar.setTimeInMillis(System.currentTimeMillis());
        //hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);


        intentV.putExtra("extra", "a soul snack");
        intentV.putExtra("nId", 77);
        calendar.set(Calendar.HOUR_OF_DAY, (hour - 1));
        calendar.set(Calendar.MINUTE, 30);
        if (toggle) {
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 66, intentV, PendingIntent.FLAG_UPDATE_CURRENT);

            alarmManager.setInexactRepeating(AlarmManager.RTC_WAKEUP,
                calendar.getTimeInMillis(),
                AlarmManager.INTERVAL_HOUR, pendingIntent);
        } else {
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 66, intentV, PendingIntent.FLAG_UPDATE_CURRENT);
            alarmManager.cancel(pendingIntent);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE, 0, 0, "Settings");
        menu.add(Menu.NONE, 1, 1, "High Score");
        menu.add(Menu.NONE, 2, 2, "Streak");
        menu.add(Menu.NONE, 3, 3, "Favorites");

		/*
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_activity_actions, menu);
        */

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case 0:
                startActivityForResult(new Intent(this, Settings.class), 0);
                return true;
            case 1:
                String highscore = null;
                try {
                    highscore = readFile(HIGHSCORE_FILENAME);

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

                // set title
                alertDialogBuilder.setTitle("High Score");

                // set dialog message
                alertDialogBuilder
                    .setMessage(highscore)
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // if this button is clicked, close
                            // current activity
                        }
                    });


                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();

                return true;
            case 2:
                String highstreak = null;
                try {
                    highstreak = readFile(HIGHSTREAK_FILENAME);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

                String curstreak = null;
                try {
                    curstreak = readFile(CURSTREAK_FILENAME);
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }


                AlertDialog.Builder alertDialogBuilder1 = new AlertDialog.Builder(this);

                // set title
                alertDialogBuilder1.setTitle("Streak");

                // set dialog message
                alertDialogBuilder1
                    .setMessage("High streak: " + highstreak + "\n" + "Current: " + curstreak)
                    .setCancelable(false)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // if this button is clicked, close
                            // current activity
                        }
                    });

                // create alert dialog
                AlertDialog alertDialog1 = alertDialogBuilder1.create();

                // show it
                alertDialog1.show();

                return true;
            case 3:
                // Get and display favorite verses:

                String favorites = "No favorites";
                try {
                    favorites = this.listJsonArray(readFile(FAVORITE_VERSES_FILENAME));
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(this);

                // set title
                alertDialogBuilder2.setTitle("Favorites");

                final Context context = this;
                // set dialog message
                alertDialogBuilder2
                    .setMessage(favorites)
                    .setNegativeButton("Reset Favorites", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            AlertDialog.Builder builder = new AlertDialog.Builder(context);
                            builder.setTitle(R.string.app_name);
                            builder.setMessage("Do you really want to clear out your favorites?");
                            builder.setIcon(R.drawable.ic_launcher);
                            builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    clearFavorites();
                                }
                            });
                            builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                }
                            });
                            AlertDialog alert = builder.create();
                            alert.show();
                        }
                    })
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // if this button is clicked, close
                            // current activity
                        }
                    });

                // create alert dialog
                AlertDialog alertDialog2 = alertDialogBuilder2.create();

                // show it
                alertDialog2.show();

                return true;
        }
        return false;
    }

    public void onResume(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        ewb.onResume();
        ewb.resumeTimers();
        mWebView.onResume();
        mWebView.resumeTimers();
    }

    @Override
    public void onPause() {
        super.onPause();  // Always call the superclass method first
        ewb.onPause();
        ewb.pauseTimers();
        mWebView.onPause();
        mWebView.pauseTimers();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        //this.removeAllViews(); //the viewgroup the webview is attached to
        destroyWebViews();
    }

    private void destroyWebViews() {
        // TODO Auto-generated method stub
        ewb.loadUrl("about:blank");
        ewb.stopLoading();
        ewb.setWebChromeClient(null);
        ewb.setWebViewClient(null);
        ewb.destroy();
        ewb = null;

        mWebView.loadUrl("about:blank");
        mWebView.stopLoading();
        mWebView.setWebChromeClient(null);
        mWebView.setWebViewClient(null);
        mWebView.destroy();
        mWebView = null;
    }






/*
	private void setupTab(final View view, final String tag) 
	{
		View tabview = createTabView(mTabHost.getContext(), tag);
		//mTabHost.getTabWidget().setStripEnabled(true);

		if (tag.equals("ESPN"))
		{
			TabSpec setContent = mTabHost.newTabSpec(tag)
					.setIndicator(tabview)
					.setContent(R.id.webview2);
			mTabHost.addTab(setContent);
		}
		else if (tag.equals("Drudge"))
		{
			TabSpec setContent = mTabHost.newTabSpec(tag)
					.setIndicator(tabview)
					.setContent(R.id.webview3);
			mTabHost.addTab(setContent);
		}
		else
		{    			
			TabSpec setContent = mTabHost.newTabSpec(tag)
					.setIndicator(tabview)
					.setContent(R.id.webview4);
			mTabHost.addTab(setContent);

		}
	}

	private static View createTabView(final Context context, final String text) {
		View view = LayoutInflater.from(context).inflate(R.layout.tabs_bg, null);
		TextView tv = (TextView) view.findViewById(R.id.tabsText);
		tv.setText(text);
		return view;
	}
*/

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
		/*
		if ( ((SlidingDrawer) findViewById(R.id.slidingDrawer1)).isOpened() && (keyCode == KeyEvent.KEYCODE_BACK) && mWebView.canGoBack()) {
			mWebView.goBack();
			return false;
		}
		if ( ((SlidingDrawer) findViewById(R.id.slidingDrawer2)).isOpened() && mTabHost.getCurrentTabTag().equals("ESPN") && (keyCode == KeyEvent.KEYCODE_BACK) && mWebView2.canGoBack())
		{
			mWebView2.goBack();
			return false;
		}
		else if ( ((SlidingDrawer) findViewById(R.id.slidingDrawer2)).isOpened() && mTabHost.getCurrentTabTag().equals("Drudge") && (keyCode == KeyEvent.KEYCODE_BACK) && mWebView3.canGoBack())
		{
			mWebView3.goBack();
			return false;
		}
		else if ( ((SlidingDrawer) findViewById(R.id.slidingDrawer2)).isOpened() && mTabHost.getCurrentTabTag().equals("TODAY") && (keyCode == KeyEvent.KEYCODE_BACK) && mWebView4.canGoBack())
		{
			mWebView4.goBack();
			return false;
		}
		*/
        return super.onKeyDown(keyCode, event);
    }

    public boolean eooClick(final View v) {

        // Hide the keys
        InputMethodManager inputManager = (InputMethodManager)
            getSystemService(getBaseContext().INPUT_METHOD_SERVICE);

        inputManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(),
            InputMethodManager.HIDE_NOT_ALWAYS);

        //RotateAnimation anim = new RotateAnimation(0.0f, 180.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        ScaleAnimation anim = new ScaleAnimation(1.0f, 0.0f, 1.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);

        // Fly up
        //Setup anim with desired properties
        anim.setInterpolator(new LinearInterpolator());
        anim.setRepeatCount(0); //Repeat animation indefinitely
        anim.setDuration(350); //Put desired duration per anim cycle here, in milliseconds
        sumoImage.animate()
            .translationYBy(400)
            .translationY(-800)
            .setDuration(getResources().getInteger(android.R.integer.config_mediumAnimTime));

        if (d1.getHeight() < 1)
            d1.setBackgroundResource(R.drawable.d5);
        if (d1.getHeight() < 1)
            d2.setBackgroundResource(R.drawable.d5);


        //Start animation
        // Roll dice:
        // Drop cup animation
        // Shake cup animation, wait till cup touched || auto on press of even/odd unveil()
        d1.startAnimation(anim);
        d2.startAnimation(anim);


        //sumoImage.setVisibility(View.INVISIBLE);

        anim.setAnimationListener(new ScaleAnimation.AnimationListener() {

            public void onAnimationRepeat(Animation arg0) {
                // TODO Auto-generated method stub

            }

            public void onAnimationStart(Animation arg0) {
                // TODO Auto-generated method stub

            }

            public void onAnimationEnd(Animation arg0) {

                //	Roll the dice
                // Get random number [1..6] + [1..6]:
                ScaleAnimation anim2 = new ScaleAnimation(0.0f, 1.0f, 1.0f, 1.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
                //Setup anim with desired properties
                anim2.setInterpolator(new LinearInterpolator());
                anim2.setRepeatCount(0); //Repeat animation indefinitely
                anim2.setDuration(350); //Put desired duration per anim cycle here, in milliseconds
                d1.startAnimation(anim2);
                d2.startAnimation(anim2);
                d1.setVisibility(View.VISIBLE);
                d2.setVisibility(View.VISIBLE);

                randomGenerator = new Random();
                randomInt1 = randomGenerator.nextInt(7 - 1) + 1;
                randomInt2 = randomGenerator.nextInt(7 - 1) + 1;
                dieSum = randomInt1 + randomInt2;


                // D1 image:
                switch (randomInt1) {
                    case 1:
                        d1.setBackgroundResource(R.drawable.d1);
                        break;
                    case 2:
                        d1.setBackgroundResource(R.drawable.d2);
                        break;
                    case 3:
                        d1.setBackgroundResource(R.drawable.d3);
                        break;
                    case 4:
                        d1.setBackgroundResource(R.drawable.d4);
                        break;
                    case 5:
                        d1.setBackgroundResource(R.drawable.d5);
                        break;
                    case 6:
                        d1.setBackgroundResource(R.drawable.d6);
                        break;
                }
                // D2 image:
                switch (randomInt2) {
                    case 1:
                        d2.setBackgroundResource(R.drawable.d1);
                        break;
                    case 2:
                        d2.setBackgroundResource(R.drawable.d2);
                        break;
                    case 3:
                        d2.setBackgroundResource(R.drawable.d3);
                        break;
                    case 4:
                        d2.setBackgroundResource(R.drawable.d4);
                        break;
                    case 5:
                        d2.setBackgroundResource(R.drawable.d5);
                        break;
                    case 6:
                        d2.setBackgroundResource(R.drawable.d6);
                        break;
                }

                anim2.setAnimationListener(new ScaleAnimation.AnimationListener() {

                    public void onAnimationRepeat(Animation arg0) {
                        // TODO Auto-generated method stub

                    }

                    public void onAnimationStart(Animation arg0) {
                        // TODO Auto-generated method stub

                    }

                    public void onAnimationEnd(Animation arg0) {
                        finishEoo(arg0, v);
                    }


                });
            }
        });

        //Toast.makeText(getBaseContext(), "Dice Rolled", Toast.LENGTH_SHORT).show();
        // Create the text view
        //TextView textView = (TextView) findViewById(R.id.wOrL);
        //textView.setTextSize(40);
        //textView.setText(WorL);
        return true;

    }

    public void finishEoo(Animation arg0, View v) {
        Boolean isCorrect = false;
        String choice = v.getTag().toString();
        if (choice.equals("even")) {
            isCorrect = (dieSum % 2 == 0);
        } else if (choice.equals("odd")) {
            isCorrect = (dieSum % 2 != 0);
        }
        //Toast.makeText(getBaseContext(), choice, Toast.LENGTH_LONG).show();


        // Current Balance
        EditText b = (EditText) rootView.findViewById(R.id.balanceBox);
        String bVal = b.getText().toString();
        int curBalance = Integer.parseInt(bVal);


        // Get the wager amount:
        EditText wagerT = (EditText) rootView.findViewById(R.id.wager);
        String wagerValue = wagerT.getText().toString();
        if (wagerValue.equals("")) {
            wagerValue = "10";
            Toast.makeText(getBaseContext(), "Wager too low, here's 10 on the house", Toast.LENGTH_SHORT).show();
            wagerT.setText(String.valueOf(wagerValue));
        }

        int wagerNum = Integer.parseInt(wagerValue);


        // Wager restrictions
        if (wagerNum >= 999999999) {
            //wagerNum = Math.abs(curBalance);
            wagerNum = 10;
            Toast.makeText(getBaseContext(), "Wager too low, here's 10 on the house", Toast.LENGTH_SHORT).show();
            wagerT.setText(String.valueOf(wagerNum));
        } else if (wagerNum <= 0) {
            wagerNum = 10;
            Toast.makeText(getBaseContext(), "Wager too low, here's 10 on the house", Toast.LENGTH_SHORT).show();
            wagerT.setText(String.valueOf(wagerNum));
        } else if (wagerNum > curBalance) {
            wagerNum = 0;
            Toast.makeText(getBaseContext(), "Can't bet what you don't got", Toast.LENGTH_SHORT).show();
            wagerT.setText(String.valueOf(wagerNum));


        }


        int newBalance = 0;
        if (isCorrect) {
            newBalance = curBalance + wagerNum;
            sumoImage.setBackgroundResource(R.drawable.sumodance);
            sumoAnim = (AnimationDrawable) sumoImage.getBackground();
            sumoAnim.start();

            String curstreak = "0";
            int curstreakInt = 0;
            try {
                curstreak = readFile(CURSTREAK_FILENAME);
                curstreakInt = Integer.parseInt(curstreak);

            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            curstreakInt++;
            fileCreate(CURSTREAK_FILENAME, String.valueOf(curstreakInt));


            String highstreak = "";
            try {
                highstreak = readFile(HIGHSTREAK_FILENAME);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            if (curstreakInt > Integer.parseInt(highstreak))
                fileCreate(HIGHSTREAK_FILENAME, String.valueOf(curstreakInt));

        } // End is correct
        else {
            // increment streak
            int curstreakInt = 0;
            fileCreate(CURSTREAK_FILENAME, String.valueOf(curstreakInt));

            // calculate loss
            newBalance = curBalance - wagerNum;
            if (newBalance <= 0) {
                newBalance = 10;
                Toast.makeText(getBaseContext(), "Lost it all, here's 10 for free", Toast.LENGTH_SHORT).show();
                String theNewB = String.valueOf(newBalance);
                b.setText(theNewB);
                wagerNum = 10;
                wagerT.setText(String.valueOf(wagerNum));
            }
            sumoImage.setBackgroundResource(R.drawable.sumosad);
        }

        sumoImage.setVisibility(View.VISIBLE);
        sumoImage.animate()
            .translationYBy(400)
            .translationY(0)
            .setDuration(getResources().getInteger(android.R.integer.config_mediumAnimTime));


        TextView text = (TextView) rootView.findViewById(R.id.results);
        text.setVisibility(View.VISIBLE);
        String str = "\n";
        if (isCorrect)
            str += "Correct!  ";
        else
            str += "Wrong!  ";
        //Toast.makeText(getBaseContext(), (CharSequence) v.getTag(), Toast.LENGTH_SHORT).show();

        str += "Sum: " + dieSum + " is " + ((dieSum % 2 == 0) ? "even" : "odd")
            + ".  Now eat some " + this.getRandomFood();


		/*
		str +=  "Sum: " + dieSum +
				"\nD1: " + randomInt1 +
				" | D2: " + randomInt2;
		 */

        ts.setText(str);


        String theNewB = String.valueOf(newBalance);
        b.setText(theNewB);
        fileCreate(BALANCE_FILENAME, theNewB);


        String highscore = "150";
        try {
            highscore = readFile(HIGHSCORE_FILENAME);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }//String.valueOf(newBalance);

        if (newBalance > Integer.parseInt(highscore))
            fileCreate(HIGHSCORE_FILENAME, theNewB);
    }

    public void allIn(View v) {
        // Current Balance
        EditText b = (EditText) rootView.findViewById(R.id.balanceBox);
        String bVal = b.getText().toString();
        int curBalance = Math.abs(Integer.parseInt(bVal));

        // Get the wager amount:
        EditText wagerT = (EditText) rootView.findViewById(R.id.wager);
        if (curBalance >= 999999999) {
            //wagerNum = Math.abs(curBalance);
            curBalance = 10;
            Toast.makeText(getBaseContext(), "Wager too high, setting to 10", Toast.LENGTH_SHORT).show();
            wagerT.setText(String.valueOf(curBalance));
        }

        Toast.makeText(getBaseContext(), "All in", Toast.LENGTH_SHORT).show();
        wagerT.setText(String.valueOf(curBalance));
    }

    private void fileCreate(String filename, String b) {
        try {
            OutputStream os = openFileOutput(filename, MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(os);
            osw.write(b);
            osw.close();
        } catch (Exception e) {
            Log.i("ReadNWrite, fileCreate()", "Exception e = " + e);
        }
    }

    private String readFile(String filename) throws IOException {
        try {
            FileInputStream fin = openFileInput(filename);
            InputStreamReader isReader = new InputStreamReader(fin);
            char[] buffer = new char[40000];
            // Fill the buffer with data from file
            isReader.read(buffer);
            fin.close();
            return new String(buffer).trim();
        } catch (FileNotFoundException e) {
            //Log.i("ReadNWrite, readFile()", "Exception e = " + e);
            if (filename.equals(BALANCE_FILENAME) || filename.equals(HIGHSCORE_FILENAME))
                return "150";
            else
                return "0";
        }
    }

    public static String convertStreamToString(InputStream is) throws Exception {
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        StringBuilder sb = new StringBuilder();
        String line = null;
        while ((line = reader.readLine()) != null) {
            sb.append(line).append("\n");
        }
        reader.close();
        return sb.toString();
    }

    public static String getStringFromFile (String filePath) throws Exception {
        File fl = new File(filePath);
        FileInputStream fin = new FileInputStream(fl);
        String ret = convertStreamToString(fin);
        //Make sure you close all streams.
        fin.close();
        return ret;
    }


    public void onTabReselected(Tab arg0, FragmentTransaction arg1) {
        // TODO Auto-generated method stub

    }

    public void onTabSelected(Tab arg0, FragmentTransaction arg1) {
        // TODO Auto-generated method stub

    }

    public void onTabUnselected(Tab arg0, FragmentTransaction arg1) {
        // TODO Auto-generated method stub

    }

    /**
     * A {@link FragmentPagerAdapter} that returns a fragment corresponding to one of the primary
     * sections of the app.
     */


    public static class AppSectionsPagerAdapter extends FragmentPagerAdapter {

        public AppSectionsPagerAdapter(FragmentManager fm) {
            super(fm);
        }

        /*
        @Override
        public Fragment getItem(int i) {
            Fragment fragment = new sumoSectionFragment();
            Bundle args = new Bundle();
            args.putInt(sumoSectionFragment.ARG_SECTION_NUMBER, i + 1); // Our object is just an integer :-P
            fragment.setArguments(args);
            return fragment;
        }
        */


        public Fragment getItem(int i) {

            switch (i) {
                case 0:
                    // The first section of the app is the most interesting -- it offers
                    // a launchpad into the other demonstrations in this example application.
                    return new gameSectionFragment();


                default:
                    // The other sections of the app are dummy placeholders.
                    Fragment fragment = new wbSectionFragment();
                    Bundle args = new Bundle();
                    args.putInt(wbSectionFragment.ARG_SECTION_NUMBER, i + 0);
                    fragment.setArguments(args);
                    return fragment;
            }
        }


        @Override
        public int getCount() {
            // For this contrived example, we have a 100-object collection.
            return 5;
        }

        @Override
        public CharSequence getPageTitle(int position) {
            switch (position) {
                case 0:
                    return "Choose Wisely";
                case 1:
                    return "ESPN";
                case 2:
                    return "DRUDGE";
                case 3:
                    return "TODAY";
                case 4:
                    return "Facts";
            }
            return "OBJECT " + (position + 1);
        }
    }

    /**
     * A fragment that launches other parts of the demo application.
     */
    public static class gameSectionFragment extends Fragment {

        static final String FILES_BACKUP_KEY = "myfiles";
        private static final String BALANCE_FILENAME = "balance.txt";
        private static final String HIGHSCORE_FILENAME = "highscore.txt";
        private static final String HIGHSTREAK_FILENAME = "highscore.streak.txt";
        private static final String CURSTREAK_FILENAME = "current.streak.txt";
        Random randomGenerator;
        int randomInt1;
        int randomInt2;
        int dieSum;


        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            rootView = inflater.inflate(R.layout.game_section, container, false);

            EditText b = (EditText) rootView.findViewById(R.id.balanceBox);
            if (theNewB != "") {
                b.setText(theNewB);
            } else {
                b.setText("150");
            }


            d1 = (ImageView) rootView.findViewById(R.id.imageView2);
            d2 = (ImageView) rootView.findViewById(R.id.imageView3);
            sumoImage = (ImageView) rootView.findViewById(R.id.imageView1);
            sumoImage.setBackgroundResource(R.drawable.sumodance);
            sumoAnim = (AnimationDrawable) sumoImage.getBackground();
            ts = (TextSwitcher) rootView.findViewById(R.id.textSwitcher1);
            View bEven = rootView.findViewById(R.id.bEven);
            View bOdd = rootView.findViewById(R.id.bOdd);

            sumoImage.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    // roll();
                    Toast.makeText(rootView.getContext(),
                        "Dice Rolled",
                        Toast.LENGTH_SHORT).show();
                    d1.setVisibility(View.INVISIBLE);
                    d2.setVisibility(View.INVISIBLE);
                    TextView text = (TextView) rootView.findViewById(R.id.results);
                    text.setVisibility(View.INVISIBLE);

                    sumoImage.setBackgroundResource(R.drawable.cupsmall);


                    // Shake the cup
                    //Then add this in code,(when and where that you can decide),
                    Animation shake = AnimationUtils.loadAnimation(rootView.getContext(), R.anim.cupshake);
                    sumoImage.startAnimation(shake);


                    if (d1.getHeight() < 1)
                        d1.setBackgroundResource(R.drawable.d5);
                    if (d1.getHeight() < 1)
                        d2.setBackgroundResource(R.drawable.d3);

                    //Start animation
                    // Roll dice:
                    // Drop cup animation
                    // Shake cup animation, wait till cup touched || auto on press of even/odd unveil()
                }
            });


            // Handle even/odd choice from notification button
            Intent intent = getActivity().getIntent();
            if (intent == null) {
                //Toast.makeText(getBaseContext(), "null inent!", Toast.LENGTH_SHORT).show();
            } else {
                //Toast.makeText(rootView.getContext(), "extras are: !" + intent.getBooleanExtra("ieven", false) + " "
                //		+ intent.getBooleanExtra("iodd",false), Toast.LENGTH_SHORT).show();
                if (intent.getBooleanExtra("iodd", false)) {
                    ((SumoActivity) getActivity()).eooClick(bOdd);
                } else if (intent.getBooleanExtra("ieven", false)) {
                    ((SumoActivity) getActivity()).eooClick(bEven);
                } else if (intent.getBooleanExtra("imore", false)) {
                    // Open todays' holidy tab
                    //Toast.makeText(rootView.getContext(), "show all hollys2", Toast.LENGTH_LONG).show();

                    //ViewPager mPager = (ViewPager) rootView.findViewById(R.id.pager);
                    //mPager.setCurrentItem(3,true);
                } else
                    Toast.makeText(rootView.getContext(), "Dice Rolled", Toast.LENGTH_SHORT).show();
                intent.removeExtra("iodd");
                intent.removeExtra("ieven");

            }


            return rootView;
        }
    }

    /**
     * A dummy fragment representing a section of the app, but that simply displays dummy text.
     */
    public static class wbSectionFragment extends Fragment {

        public static final String ARG_SECTION_NUMBER = "arg_sec_num";

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                                 Bundle savedInstanceState) {
            View espnView = inflater.inflate(R.layout.webview_section, container, false);
            Bundle args = getArguments();

            Log.v("argsj", "ASDF: " + args.getInt(ARG_SECTION_NUMBER));


            //((TextView) rootView.findViewById(android.R.id.text1)).setText(
            //        getString(R.string.hello, args.getInt(ARG_SECTION_NUMBER)));

            ewb = (WebView) espnView.findViewById(R.id.espnWebView);
            ewb.getSettings().setJavaScriptEnabled(true);
            ewb.getSettings().setSupportMultipleWindows(true);
            ewb.getSettings().setAllowFileAccess(true);
            ewb.getSettings().setBuiltInZoomControls(true);
            ewb.getSettings().setLoadWithOverviewMode(true);
            ewb.getSettings().setUseWideViewPort(true);
            ewb.setWebChromeClient(new WebChromeClient());

            ewb.clearCache(true);
            switch (args.getInt(ARG_SECTION_NUMBER)) {
                case 1:
                    ewb.loadUrl("https://espn.go.com");
                    break;
                case 2:
                    ewb.loadUrl("https://www.drudgereport.com");
                    break;
                case 3:
                    ewb.loadUrl("https://checkiday.com");
                    break;
                case 4:
                    ewb.loadUrl("https://www.factretriever.com/");
                    break;
            }


            //ewb.setWebViewClient(new SumoWebViewClient());

            ewb.setWebViewClient(new WebViewClient() {
                public boolean shouldOverrideUrlLoading(WebView view, String url) {
                    view.loadUrl(url);
                    return false;
                }
            });

            return espnView;
        }

		/*
    	private class SumoWebViewClient extends WebViewClient {
    		@Override
    		public boolean shouldOverrideUrlLoading(WebView view, String url) {
    			//view.clearCache(true);
    			view.loadUrl(url);
    			return true;
    		}
    	}
    	*/

    }

    private class PreferenceChangeListener implements OnSharedPreferenceChangeListener {
        private static final String KEY_REMINDER = "reminders";
        private static final String KEY_SNACK = "snackReminders";
        private static final String KEY_SOUL = "soulSnackReminders";


        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            // TODO Auto-generated method stub
            if (key.equals(KEY_REMINDER)) {

                if (sharedPreferences.getBoolean(KEY_REMINDER, true)) {
                    Toast.makeText(getBaseContext(), "Meal reminders on", Toast.LENGTH_SHORT).show();
                    remindersToggle(true);
                } else {
                    Toast.makeText(getBaseContext(), "Meal reminders off", Toast.LENGTH_SHORT).show();
                    remindersToggle(false);
                }
            }
            // TODO Auto-generated method stub
            else if (key.equals(KEY_SNACK)) {

                if (sharedPreferences.getBoolean(KEY_SNACK, true)) {
                    Toast.makeText(getBaseContext(), "Snack reminders on", Toast.LENGTH_SHORT).show();
                    snackRemindersToggle(true);
                } else {
                    Toast.makeText(getBaseContext(), "Snack reminders off", Toast.LENGTH_SHORT).show();
                    snackRemindersToggle(false);
                }
            }
            // TODO Auto-generated method stub
            else if (key.equals(KEY_SOUL)) {

                if (sharedPreferences.getBoolean(KEY_SOUL, true)) {
                    Toast.makeText(getBaseContext(), "Soul Snack reminders on", Toast.LENGTH_SHORT).show();
                    soulSnackRemindersToggle(true);
                } else {
                    Toast.makeText(getBaseContext(), "Soul Snack reminders off", Toast.LENGTH_SHORT).show();
                    soulSnackRemindersToggle(false);
                }
            }
        }
    }

    private class HelloWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            //view.clearCache(true);
            view.loadUrl(url);
            return false;
        }
    }
}
