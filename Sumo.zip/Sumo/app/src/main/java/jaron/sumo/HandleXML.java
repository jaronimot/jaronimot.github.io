package jaron.sumo;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

@SuppressLint("NewApi")
public class HandleXML {
    private String title = "title";
    private String link = "link";
    private String description = "description";
    private String urlString = null;
    private XmlPullParserFactory xmlFactoryObject;
    private Notification.InboxStyle ib = null;
    public String allHolidays = "";
    public int counter = 0;
    public int allCounter = 0;
    public int moreCounter = 0;
    public String extraLines = "";
    public boolean inetConnected = false;
    public volatile boolean parsingComplete = true;
    public String message = "";

    public HandleXML(String url) {
        this.urlString = url;
    }

    public String getTitle() {
        return title;
    }

    public String getLink() {
        return link;
    }

    public String getDescription() {
        return description;
    }

    public void parseXMLAndStoreIt(XmlPullParser myParser) {
        int event;
        String text = null;

        try {
            event = myParser.getEventType();

            while (event != XmlPullParser.END_DOCUMENT) {
                String name = myParser.getName();

                switch (event) {
                    case XmlPullParser.START_TAG:
                        break;

                    case XmlPullParser.TEXT:
                        try {
                            text = myParser.getText();
                            text = text.replaceAll("(&[^\\s]+?;)", ":)");

                        } catch (Exception e) {
                            text = "nno";
                        }
                        break;

                    case XmlPullParser.END_TAG:

                        if (name.equals("title")) {
                            //title = text;
                        } else if (name.equals("link")) {
                            //link = text;
                        } else if (name.equals("description")) {
                            // Add this to inbox style list:
                            if (text.startsWith("Today")) {
                                if (null != ib) {
                                    if (counter < 6) {
                                        try {
                                            // Jaron 4/9/2021: Just use big text with new lines instead:
//										ib.addLine(text);
                                            counter++;
                                        } catch (Exception e) {
                                            ib.addLine("Can't add");
                                        }
                                    } else {
                                        try {
                                            moreCounter++;
                                            extraLines += text + "  ";
                                        } catch (Exception e) {
                                        }
                                    }
                                }
                                allCounter++;
                                allHolidays += (allCounter > 1 ? "\n" : "") + text;
                            }
                        }

                        break;
                }

                event = myParser.next();
            }

            parsingComplete = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void fetchXML(Notification.InboxStyle ibp, final Notification.Builder mb) {
        ib = ibp;

        Log.d("STATE", urlString);
        if (urlString.contains("checkiday")) {
            Thread thread1 = new Thread(new Runnable() {
                public void run() {
                    try {
                        Log.d("STATE", "Get today's' holidays");

                        URL url = new URL(urlString);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                        conn.setReadTimeout(10000);
                        conn.setConnectTimeout(15000);
                        conn.setRequestMethod("GET");
                        conn.setDoInput(true);

                        // Starts the query
                        conn.connect();
                        if (conn.getResponseCode() == 200) {
                            InputStream stream = conn.getInputStream();
                            xmlFactoryObject = XmlPullParserFactory.newInstance();
                            XmlPullParser myparser = xmlFactoryObject.newPullParser();

                            myparser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
                            myparser.setFeature(Xml.FEATURE_RELAXED, true);
                            myparser.setInput(stream, null);

                            parseXMLAndStoreIt(myparser);
                            Log.d("STATE", " parser hereGET tdoays' holis");

                            stream.close();
                        } else
                            ib.addLine("NOINET00");

                        //System.out.println("NOINET00");
                        //Toast.makeText(Context, "no inet", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                    }
                }
            });

            thread1.start();

            try {

                thread1.join();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }

        Log.d("DEBUG", "urlString: " + urlString);

        if (urlString.contains("ourmanna")) {
            Log.d("DEBUG", urlString);

            Thread thread2 = new Thread(new Runnable() {
                public void run() {
                    try {
                        Log.d("STATE", "Get a verse");
                        StringBuilder response = new StringBuilder();

                        String verse = "";

                        URL url = new URL(urlString);
                        HttpURLConnection httpconn = (HttpURLConnection) url.openConnection();
                        Log.d("STATE", "Get url: " + urlString);
                        Log.d("STATE", "CONN: " + httpconn.getResponseMessage());

                        if (httpconn.getResponseCode() == 200) {
                            Log.d("STATE", "OK HTTP");

                            BufferedReader input = new BufferedReader(new InputStreamReader(httpconn.getInputStream()), 8192);
                            String strLine = null;
                            int i = 0;
                            while ((strLine = input.readLine()) != null) {
                                response.append(strLine);
                                i++;
                            }
                            input.close();
                            message = response.toString();

                            Log.d("STATE", "JAR manna 1: " + response.toString());
                        } else {
                            Log.d("STATE", "No HTTP");
                        }
                        verse = response.toString();
                        if (!verse.equals("")) {
                            mb.setStyle(new Notification.BigTextStyle()
                                .bigText(verse)
                                .setSummaryText(verse)
                            );
                            message = response.toString();
                        }
                    } catch (IOException e) {
                        //Toast.makeText(this, "Caught IOException", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        //Toast.makeText(this, "Caught Exception", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            thread2.start();
            Log.d("STATE", "JARRRR: START THREAD 2");


            try {
                thread2.join();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }


    public void getHolidayString() {

        Log.d("STATE", urlString);
        if (urlString.contains("checkiday")) {
            Thread thread = new Thread(new Runnable() {
                public void run() {
                    try {
                        Log.d("STATE", "Get today's' holidays");

                        URL url = new URL(urlString);
                        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                        conn.setReadTimeout(10000);
                        conn.setConnectTimeout(15000);
                        conn.setRequestMethod("GET");
                        conn.setDoInput(true);

                        // Starts the query
                        conn.connect();
                        if (conn.getResponseCode() == 200) {
                            InputStream stream = conn.getInputStream();
                            xmlFactoryObject = XmlPullParserFactory.newInstance();
                            XmlPullParser myparser = xmlFactoryObject.newPullParser();

                            myparser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
                            myparser.setFeature(Xml.FEATURE_RELAXED, true);
                            myparser.setInput(stream, null);

                            parseXMLAndStoreIt(myparser);
                            Log.d("STATE", " parser hereGET tdoays' holis");

                            stream.close();
                        } else
                            ib.addLine("NOINET00");

                        //System.out.println("NOINET00");
                        //Toast.makeText(Context, "no inet", Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                    }
                }
            });

            thread.start();
            try {
                thread.join();
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }


    private String convertStreamToString(InputStream is) {
        String line = "";
        StringBuilder total = new StringBuilder();
        BufferedReader rd = new BufferedReader(new InputStreamReader(is));
        try {
            while ((line = rd.readLine()) != null) {
                total.append(line);
            }
        } catch (Exception e) {
            //Toast.makeText(this, "Stream Exception", Toast.LENGTH_SHORT).show();
        }
        return total.toString();
    }
}
